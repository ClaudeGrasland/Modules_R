# repurrrsive 1.1.0

* Some NSFW content has been removed from `got_chars` (#26).

* `gmaps_cities` is a new dataset, containing the results of geocoding five
  US cities.

# repurrrsive 1.0.0

* `discog` is a new dataset, containing Sharla Gelfand's discography, inspired
  by <https://sharla.party/post/discog-purrr/> and used in a new tidyr
  vignette on rectangling.

# repurrrsive 0.1.0

* Initial CRAN release
