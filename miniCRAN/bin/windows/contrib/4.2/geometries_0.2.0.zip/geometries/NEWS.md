# geometries 0.2.0

* user can add `closed` attribute added to shapes if the first row is reapeated at the end of a matrix
* `nest.hpp` - re-enabled
* `columns.hpp` - templated `column_positions()` and handles data.frame inputs
