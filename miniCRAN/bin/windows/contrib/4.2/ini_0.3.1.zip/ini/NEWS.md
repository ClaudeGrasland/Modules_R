# ini 0.3.1

* Patch to fix unnecessary space between "=" (#2)