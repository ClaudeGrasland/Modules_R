
library(RcppSimdJson)

expect_stdout(parseExample())
