LeafletWidget.methods.spinner = function(
    state, options) {
      var map = this;
      map.spin(state, options);
    };
