## plainview 0.2.0 (2022-04-10)

#### ✨ features and improvements

#### 🐛 bug fixes

#### 💬 documentation etc

#### 🍬 miscellaneous

  * suggest `sf` and use translate util in favour of `gdalUtils::gdal_translate`.

## plainview 0.1.2 (2022-02-07)

miscellaneous:

  * switch to `gdalUtilities::gdal_translate` from `gdalUtils::gdal_translate` as requested by Prof. Brian Ripley (via email).

## plainview 0.1.1

bug fixes:

  * allow at to be missing and NULL.

## plainview 0.1.0

* Initial release
