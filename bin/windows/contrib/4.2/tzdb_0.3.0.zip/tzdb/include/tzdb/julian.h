#ifndef TZDB_JULIAN_H
#define TZDB_JULIAN_H

#include <tzdb/defines.h>
#include <date/julian.h>

#endif
